$.fn.bootstrapValidator.validators.bnf_ratio = {
	validate : function(validator, $field, options) {
	 
		var topvueobj = getTopvueObj(options.vueobj);
		var insuidStart = options.vueobj.namepref.indexOf("_");
		var insuid = options.vueobj.namepref.substring(insuidStart + 1);
		var bnfAry = topvueobj.formdata.bnf;

		var form = $(options.vueobj.$el).parentsUntil("form").parent("form");
		// options.vueobj.formdata ;

		var bnflot=0;
        var bnflot2=0;
		for (var i = 0; i < bnfAry.length; i++) {
			var bnf = bnfAry[i];
			// /判断 //同被保险人
			for ( var key in bnf.mapRelevant) {
				/*insuid == key;*/
				/*if (insuid == key) {*/
					// if($("[id='bnflot"+i+"']").is(":visible")){
					if (!isNaN(bnf.mapRelevant[key].bnflot)) {
						if(key=="1"){
							bnflot = bnflot
							+ Number(bnf.mapRelevant[key].bnflot);
						}else if(key=="2"){
							bnflot2 = bnflot2
							+ Number(bnf.mapRelevant[key].bnflot);
						}else if(key=="1,2"){
							bnflot = bnflot
							+ Number(bnf.mapRelevant[key].bnflot);
							bnflot2 = bnflot2
							+ Number(bnf.mapRelevant[key].bnflot);
						}
						
					}

					// }
					//					
				/*}*/

			}
		}
		

		// for (var i = 0; i < bnfAry.length; i++) {
		// var bnf = bnfAry[i];
		// ///判断 //同被保险人
		// for ( var key in bnf.mapRelevant) {
		// if (insuid == key) {
		//					 
		// if($("[id='bnflot"+i+"']").is(":visible")){
		// try {
		//							
		// if(bnflot==100){
		//								
		// form.data('bootstrapValidator').updateStatus($("[id='bnflot"+i+"']:visible"),"VALID");
		//								
		// }else{
		//								
		// form.data('bootstrapValidator').updateStatus($("[id='bnflot"+i+"']:visible"),"INVALID");
		//								
		// }
		// } catch (e) {
		// }
		//						
		// }
		// }
		//				 
		// }
		//			
		// }
       
        	if (bnflot == 100) {

    			form.data('bootstrapValidator').updateStatus($field, "VALID");

    			form.find("input[id*='bnflot']").each(function() {

    				if (!form.data('bootstrapValidator').isValidField($(this))) {
    					form.data('bootstrapValidator').revalidateField($(this));
    				}

    			});
    			
    			if(bnflot2!=0){
    				if(bnflot2==100){
    					return true;
    				}else{
    					return false;
    				}
    			}
    			return true;
    		}else  if(bnflot2==100){
    			
    			return true;
    		} else {
			
			return false;
		}

		return true;

	}
};

bootstrap_valid.bnf_ratio = function(validitem) {

	var vueobj = this;
	var validobj = {
		message : "该被保人受益人比例之和不为100",
		vueobj : vueobj
	};

	return validobj;

};

vueMethods.getBnfRelTitle = function(value, indexbnfno, insuids) {
	if (value == "1") {
		var topvue = getTopvueObj(this);
		if(topvue.formdata.newContApply.investment=='N'){
			return "主被保险人";
		}else{
			return "第一被保险人";
		}
		
	}
	if (value == "2") {
		return "第二被保险人";
	}

	if (value == "1,2") {
		return "两被保人均身故";
	}
};

vueMethods.getBnFRelData = function(formdata, mapkey, key) {
	if (formdata[mapkey] == undefined) {

		this.$set(formdata, mapkey, {});
	} else {

	}

	if (formdata[mapkey][key] == undefined) {

		this.$set(formdata[mapkey], key, {});
	} else {

	}

	return formdata[mapkey][key];
};
// getBnFRelData(formdata['bnf'][n-1]['mapRelevant'],insuid)
/*******************************************************************************
 * 受益人 与被保人关系
 */
vueMethods.getBnfRelship = function(SID, objvalue, num_index) {

	var elments = [];
	var aryindex = {};
	
	if (this.form_elements[SID]) {
		try {
			console.log("objvalue length" + objvalue + " SID:" + SID);
		} catch (e) {
			console.log(e);
		}
		var formdata = this.formdata;
	    
		if (formdata['lcinsured']
		&& formdata['lcinsured'].lcinsuredtwoflag
		&& formdata['lcinsured'].lcinsuredtwoflag.length >= 1
		&& formdata['lcinsured'].lcinsuredtwoflag[0] == 'lcinsuredtwoflag') {
		    			
		} else {			
		  
			if(formdata['bnf'][num_index].insuids
					&&formdata['bnf'][num_index].insuids.length==1
					&&formdata['bnf'][num_index].insuids[0]=="1"){
				
			}else{
				objvalue=["1"];
				formdata['bnf'][num_index].insuids=[];
				formdata['bnf'][num_index].insuids.push("1");
//				this.$set(formdata['bnf'][num_index].insuids,"insuids",["1"]);
			}
			
		}
		if (objvalue != undefined) {

			var firstInsu = false;
			var secondInsu = false;
			var bothInsu = false;
		
			

			for ( var index in objvalue) {

				if (objvalue[index] == "1") {
					firstInsu = true;
				}

				if (objvalue[index] == "2") {
					secondInsu = true;
				}

				if (objvalue[index] == "1,2") {
					firstInsu = true;
					secondInsu = true;
					bothInsu = true;
				}
			}

			// 显示与第一个被保险人关系
			if (firstInsu) {
				elments.push(this.form_elements[SID][0]);
				aryindex[0] = true;

			} else {

			}
			// 显示与第二个被保险人关系
			if (secondInsu) {
				elments.push(this.form_elements[SID][1]);
				aryindex[1] = true;

			} else {

			}

			var changeFlag = false;// 变化 标志
			if (!firstInsu
					&& this.formdata.bnf[num_index].mapRelevant!= undefined
					&& this.formdata.bnf[num_index].mapRelevant['1'] != undefined
					&& this.formdata.bnf[num_index].mapRelevant['1'].bnflot != undefined) {
				this.$set(this.formdata.bnf[num_index].mapRelevant, '1', {});
				changeFlag = true;

			}

			if (!secondInsu
					&& this.formdata.bnf[num_index].mapRelevant!= undefined
					&& this.formdata.bnf[num_index].mapRelevant['2'] != undefined
					&& this.formdata.bnf[num_index].mapRelevant['2'].bnflot != undefined) {
				this.$set(this.formdata.bnf[num_index].mapRelevant, '2', {});
				changeFlag = true;

			}

			if (!bothInsu
					&& this.formdata.bnf[num_index].mapRelevant!= undefined
					&& this.formdata.bnf[num_index].mapRelevant['1,2'] != undefined
					&& this.formdata.bnf[num_index].mapRelevant['1,2'].bnflot != undefined) {
				this.$set(this.formdata.bnf[num_index].mapRelevant, '1,2', {});
				changeFlag = true;
			}
			// 受益人所属被保人 变化后 重新 valid 部分字段
			if (changeFlag) {
				$("#lcbnf_tabinfoform").find("input[id*='bnflot']").each(
						function() {

							$("#lcbnf_tabinfoform").data('bootstrapValidator')
									.revalidateField($(this));

						});

			}

		}
		// 清空元素值
		for ( var index in this.form_elements[SID]) {
			if (aryindex[index]) {

			} else {

				var element = this.form_elements[SID][index];
				this.$set(this.formdata[element.groupid][num_index],
						element.name, "");
			}
		}

	}

	return elments;

};

commonCombobox_option.commonCombobox_relationbnf_insh = {

		url : path + '/newCont/codeselect/common/bnf/relation_insh',
		valueField : "code",
		relateType: "vue",
		// 显示在输入框的
		inputText :  "codename" ,
		textShow : [ "codename" ],
	};
afterVueSelect.relationtoinsuredinsh = function(form_element) {
	var topvue = getTopvueObj(this);
	for(var i =0;i<vueobj["testdivchange"].formdata.bnf.length;i++){
	var relationtoinsured=vueobj["testdivchange"].formdata.bnf[i].relationtoinsured;
	if(relationtoinsured!="30"){		
//		$(" input[ name='bnf["+i+"].otherrelation' ] ").attr("disabled",true);
//		$(" input[ name='bnf["+i+"].otherrelation' ] ").val("");
		$("#lcbnfotherrelation\\["+i+"\\]").attr("disabled",true);
		$("#lcbnfotherrelation\\["+i+"\\]").val("");
		topvue.$set(topvue.formdata.bnf[i],"otherrelation","");
	}else{
		$("#lcbnfotherrelation\\["+i+"\\]").removeAttr("disabled");			
	}			
	};
}


//根据身份证号，同步出生日期
afterVueSelect.lcbnfidno = function(form_element) {
	var topvue = getTopvueObj(this);
	for(var i=0;i<topvue.formdata.bnf.length;i++){
		if(topvue.formdata.bnf[i].idtype != "I"&&topvue.formdata.bnf[i].idtype != "J"){
			return;
		}
		if(topvue.formdata.bnf[i].idtype == "I"||topvue.formdata.bnf[i].idtype == "J"){
				var idno = topvue.formdata.bnf[i].idno;
				var birthday = idno.substring(6,14);
				var year = birthday.substring(0,4);
				var mon = birthday.substring(4,6);
				var day = birthday.substring(6);
				var formatBirth = year + "-" + mon + "-" + day;
				topvue.$set(topvue.formdata.bnf[i],"birthday",formatBirth);		
		}
	}
}
$.fn.bootstrapValidator.validators.bnf_idno = {
		validate : function(validator, $field, options) {
			var num=$(options.vueobj.$el).children().attr("id").split("[")[1].substring(0,1);
			var topvueobj = getTopvueObj(options.vueobj);
			var bnfAry = topvueobj.formdata.bnf;
			var form = $(options.vueobj.$el).parentsUntil("form").parent("form");
			var length=bnfAry.length;
			bnf=bnfAry[num];
			if(bnf.idno.length==18||(bnf.idtype!="I"&&bnf.idtype!="J")){
				form.data('bootstrapValidator').resetField($("#lcbnfbirthday\\["+num+"\\]"));
				form.data('bootstrapValidator').updateStatus($field, "VALID");
				form.find("input[id*='lcbnfidno']").each(function() {
					if (!form.data('bootstrapValidator').isValidField($(this))) {
						form.data('bootstrapValidator').revalidateField($(this));
					}

				});
				return true;
			}
			return false;
		}
	};
	bootstrap_valid.bnf_idno = function(validitem) {
		var vueobj = this;
		var validobj = {
			message : "当前证件类型下证件号码必须为18位，请重新输入",
			vueobj : vueobj
		};

		return validobj;

	};
